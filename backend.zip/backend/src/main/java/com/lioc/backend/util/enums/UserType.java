package com.lioc.backend.util.enums;

public enum UserType {
    CUSTOMER,
    SUPPLIER
}
